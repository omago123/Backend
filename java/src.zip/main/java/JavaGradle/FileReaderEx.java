//package JavaGradle;
//
//class Contact{
//    private String name;
//    private String phoneNum;
//
//    public Contact(String name,String phoneNum
//}
//
//
//
