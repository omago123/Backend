package Socket;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class Test01 {
    public static void main(String[] args) {
        try (ServerSocketChannel server = ServerSocketChannel.open()){
            // 서버에 접속한다.
            server.bind(new InetSocketAddress(8080));
            // 논블로킹모드를 사용한다.
            server.configureBlocking(false);


            System.out.println("서버가 시작되었습니다.");

            Selector selector = Selector.open();

            //서버에 등록한다.
            server.register(selector, SelectionKey.OP_ACCEPT);

            while (selector.select() > 0){
                Iterator<SelectionKey> it = selector.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey key = it.next();
                    it.remove();

                    if (key.isAcceptable()){
                        ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
                        SocketChannel client = serverChannel.accept();
                        client.configureBlocking(false);
                        client.register(selector, SelectionKey.OP_WRITE);

                    } else if (key.isWritable()) {
                        try (SocketChannel client = (SocketChannel) key.channel()){
                            ByteBuffer buffer = ByteBuffer.allocate(1024);

                            buffer.put("HTTP/1.0 200 OK\n".getBytes());
                            buffer.put("Content-Type: text/html\n\n".getBytes());
                            for (int i = 0; i < 5 ; i++) {
                                buffer.put("<h1>Have a nice day!!</h1>".getBytes());
                                Thread.sleep(1000);
                            }

                            buffer.flip();
                            client.write(buffer);
                        }
                    }
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
